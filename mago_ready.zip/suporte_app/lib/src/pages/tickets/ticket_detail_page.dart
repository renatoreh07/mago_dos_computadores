import 'package:flutter/material.dart';

class TicketDetailPage extends StatelessWidget {
  final Map<String,dynamic> ticket;
  const TicketDetailPage({Key? key, required this.ticket}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Detalhe do ticket')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Text(ticket['description'] ?? '---'),
      ),
    );
  }
}
