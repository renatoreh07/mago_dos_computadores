Projeto Mago dos Computadores - App Flutter (offline demo)

- Login técnico: tecnico@mago.com / 123456
- App funciona offline (IA simulada)
- Para gerar APK: rode flutter build apk no seu ambiente ou use CI como Codemagic/GitHub Actions.
